* Enable drag/drop in Ace editor (#367)
* Fix multi-change event errors in Monaco (#380)
